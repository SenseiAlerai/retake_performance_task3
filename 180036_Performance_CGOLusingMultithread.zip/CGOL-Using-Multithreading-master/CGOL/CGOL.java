package CGOL;

import java.util.Scanner;

// A simple Java program to implement Game of Life 
public class CGOL { 
	public static void main(String[] args) 
	{ 
		int M = 5, N = 5; 
		int [][] grid = new int[M][N];

		System.out.println("                Remember!!! ");
		System.out.println("Zero means dead cell & non zere are live cell. ");
		System.out.println("Enter the grid: ");
		Scanner sc = new Scanner(System.in);
		int i,j;
		for(i=0;i<5;i++) {
			for(j=0;j<5;j++) {
				grid[i][j]=sc.nextInt();
			}
		}
		
		// Displaying the grid 
		System.out.println("Original Generation"); 
		for ( i = 0; i < M; i++) 
		{ 
			for (j = 0; j < N; j++) 
			{ 
				if (grid[i][j] == 0) 
					System.out.print("0"); 
				else
					System.out.print("*"); 
			} 
			System.out.println(); 
		} 
		System.out.println(); 

		
		Logic logic=new Logic(M, N, grid);
		logic.start();
		
	} 
} 
